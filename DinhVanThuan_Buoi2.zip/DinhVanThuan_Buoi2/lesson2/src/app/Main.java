package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import controller.Logic;
import entities.GiaoDichTienTe;
import entities.GiaoDichVang;

public class Main {

	public static void showMenu() {
		System.out.println("__________Menu____________");
		System.out.println("1. Nhap xuat giao dich vang");
		System.out.println("2. Nhap xuat giao dich tien te");
		System.out.println("3. Tinh Tong so luong cho tung loai");
		System.out.println("4. Tinh trung binh thanh tien cua giao dich tien te");
		System.out.println("5. Xua ra cac giao dic co don gia > 1 ty");
		System.out.println("0. Exit");
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int option;
		Logic logic = new Logic();
		List<GiaoDichVang> listVang = new ArrayList<>();
		List<GiaoDichTienTe> listTien = new ArrayList<>();
		boolean exit = true;
		while (exit) {
			if (exit) {
				showMenu();
			}
			System.out.print("Nhap lua chon cua ban: ");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				logic.inputGiaoDichVang();
				logic.outputGiaoDichVang();
				break;
			case 2:
				logic.inputGiaoDichTienTe();
				logic.outputGiaoDichTienTe();
				break;

			default:
				break;
			}
		}
		scanner.close();
	}
}
