package entities;

public class GiaoDichVang extends GiaoDich {
	private String loaiVang;

	public GiaoDichVang() {
	}

	public GiaoDichVang(String maGiaoDich, DayMonthYear ngayGiaoDich, double donGia, int soLuong, double thanhTien,
			String loaiVang) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong, thanhTien);
		this.loaiVang = loaiVang;
	}

	public String getLoaiVang() {
		return loaiVang;
	}

	public void setLoaiVang(String loaiVang) {
		this.loaiVang = loaiVang;
	}

	@Override
	public String toString() {
		return "GiaoDichVang" + super.toString() + " [loaiVang=" + loaiVang + "]";
	}

}
