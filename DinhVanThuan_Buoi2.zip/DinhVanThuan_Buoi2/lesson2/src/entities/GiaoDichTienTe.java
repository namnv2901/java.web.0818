package entities;

public class GiaoDichTienTe extends GiaoDich {
	private float tiGia;

	public GiaoDichTienTe() {
	}

	public GiaoDichTienTe(String maGiaoDich, DayMonthYear ngayGiaoDich, double donGia, int soLuong, double thanhTien,
			float tiGia) {
		super(maGiaoDich, ngayGiaoDich, donGia, soLuong, thanhTien);
		this.tiGia = tiGia;
	}

	public float getTiGia() {
		return tiGia;
	}

	public void setTiGia(float tiGia) {
		this.tiGia = tiGia;
	}

	@Override
	public String toString() {
		return "GiaoDichTienTe" + super.toString() + " [tiGia=" + tiGia + "]";
	}
	
}
