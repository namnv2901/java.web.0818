package entities;

public class Money {
	private String vn;
	private String usd;
	private String euro;

	public Money() {
	}

	public Money(String vn, String usd, String euro) {
		super();
		this.vn = vn;
		this.usd = usd;
		this.euro = euro;
	}

	public String getVn() {
		return vn;
	}

	public void setVn(String vn) {
		this.vn = vn;
	}

	public String getUsd() {
		return usd;
	}

	public void setUsd(String usd) {
		this.usd = usd;
	}

	public String getEuro() {
		return euro;
	}

	public void setEuro(String euro) {
		this.euro = euro;
	}

}
