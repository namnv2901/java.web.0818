package entities;

public class GiaoDich {
	private String maGiaoDich;
	private DayMonthYear ngayGiaoDich;
	private double donGia;
	private int soLuong;
	private double thanhTien;

	public GiaoDich() {
	}

	public GiaoDich(String maGiaoDich, DayMonthYear ngayGiaoDich, double donGia, int soLuong, double thanhTien) {
		super();
		this.maGiaoDich = maGiaoDich;
		this.ngayGiaoDich = ngayGiaoDich;
		this.donGia = donGia;
		this.soLuong = soLuong;
		this.thanhTien = thanhTien;
	}

	public String getMaGiaoDich() {
		return maGiaoDich;
	}

	public void setMaGiaoDich(String maGiaoDich) {
		this.maGiaoDich = maGiaoDich;
	}

	public DayMonthYear getNgayGiaoDich() {
		return ngayGiaoDich;
	}

	public void setNgayGiaoDich() {
		ngayGiaoDich = new DayMonthYear();
		ngayGiaoDich.inputDate();
	}

	public double getDonGia() {
		return donGia;
	}

	public void setDonGia(double donGia) {
		this.donGia = donGia;
	}

	public int getSoLuong() {
		return soLuong;
	}

	public void setSoLuong(int soLuong) {
		this.soLuong = soLuong;
	}

	public double getThanhTien() {
		return thanhTien;
	}

	public void setThanhTien(double thanhTien) {
		this.thanhTien = soLuong * donGia;
	}

	@Override
	public String toString() {
		return " [maGiaoDich=" + maGiaoDich + ", ngayGiaoDich=" + ngayGiaoDich + ", donGia=" + donGia
				+ ", soLuong=" + soLuong + ", thanhTien=" + thanhTien + "]";
	}

}
