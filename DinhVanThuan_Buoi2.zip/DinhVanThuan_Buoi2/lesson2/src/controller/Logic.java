package controller;

import java.util.Scanner;

import entities.GiaoDich;
import entities.GiaoDichTienTe;
import entities.GiaoDichVang;

public class Logic {
	GiaoDich giaoDich = new GiaoDich();
	GiaoDichVang giaoDichVang = new GiaoDichVang();
	GiaoDichTienTe giaoDichTienTe = new GiaoDichTienTe();
	Scanner scanner = new Scanner(System.in);

	public void inputGiaoDich() {
		System.out.print("Ma giao dich: ");
		giaoDich.setMaGiaoDich(scanner.nextLine());
		System.out.println("Ngay giao dich: ");
		giaoDich.setNgayGiaoDich();
		System.out.print("Don gia: ");
		giaoDich.setDonGia(scanner.nextDouble());
		System.out.print("So Luong: ");
		giaoDich.setSoLuong(scanner.nextInt());
		scanner.nextLine();
		giaoDich.setThanhTien(giaoDichVang.getSoLuong() * giaoDichVang.getDonGia());
	}

	public void inputGiaoDichVang() {
		inputGiaoDich();
		System.out.print("Loai vang: ");
		giaoDichVang.setLoaiVang(scanner.nextLine());
	}

	public void outputGiaoDichVang() {
		System.out.println(giaoDichVang.toString());
	}

	public void inputGiaoDichTienTe() {
		inputGiaoDich();
		System.out.print("Ti gia:  ");
		giaoDichTienTe.setTiGia(scanner.nextFloat());
	}

	public void outputGiaoDichTienTe() {
		System.out.println(giaoDichTienTe.toString());
	}
}
