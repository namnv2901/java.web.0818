package entities;

public class KhachHang {
	private String maKH;
	private String hoTen;
	private DateMonthYear date;
	private String donGia;
	
	

}
