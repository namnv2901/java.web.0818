package controller;

import java.util.Scanner;

import entities.Car;
import entities.CarNgoaiThanh;
import entities.CarNoiThanh;

public class Function {
	public Car car = new Car();
	public CarNoiThanh carNoiThanh = new CarNoiThanh();
	public CarNgoaiThanh carNgoaiThanh = new CarNgoaiThanh();
	public Scanner scanner = new Scanner(System.in);

	public void input() {
		System.out.println("Nhap ma so chuyen: ");
		car.setMaSoChuyen(scanner.nextLine());
		System.out.println("Ten Tai xe: ");
		car.setTenTaiXe(scanner.nextLine());
		System.out.println("Nhap So xe");
		car.setSoXe(scanner.nextInt());
		scanner.nextLine();
		System.out.println("Doanh thu: ");
		car.setDoanhThu(scanner.nextDouble());
		scanner.nextLine();
	}

	public void inputNgoaiThanh() {
		input();
		System.out.println("Nhap noi den");
		carNgoaiThanh.setNoiDen(scanner.nextLine());
		System.out.println("So ngay di duoc");
		carNgoaiThanh.setSoNgayDiDuoc(scanner.nextDouble());
		scanner.nextLine();
	}

	public void outputNgoaiThanh() {
		car.display();
		carNgoaiThanh.show();
	}

	public void inputNoiThanh() {
		input();
		System.out.println("Nhap so tuyen: ");
		carNoiThanh.setSoTuyen(scanner.nextInt());
		scanner.nextLine();
		System.out.println("Nhap so km di duoc");
		carNoiThanh.setSoKmDiDuoc(scanner.nextDouble());
		scanner.nextLine();
	}
	
	public void outputNoiThanh() {
		car.display();
		carNoiThanh.show();
	}
}
