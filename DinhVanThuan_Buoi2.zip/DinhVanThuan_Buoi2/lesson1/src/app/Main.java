package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import controller.Function;
import entities.CarNgoaiThanh;
import entities.CarNoiThanh;

public class Main {

	public static void showMenu() {
		System.out.println("__________________Menu__________________");
		System.out.println("1. Them xe ngoai thanh");
		System.out.println("2. Hien thi xe noi thanh");
		System.out.println("3. Them xe noi thanh");
		System.out.println("4. Hien thi xe noi thanh");
		System.out.println("0. Exit");
	}

	public static void main(String[] args) {
		Function function = new Function();
		// function.inputNgoaiThanh();
		// function.outputNgoaiThanh();
		// function.inputNoiThanh();
		// function.outputNoiThanh();
		List<CarNgoaiThanh> listNgoaiThanh = new ArrayList<>();
		List<CarNoiThanh> listNoiThanh = new ArrayList<>();
		boolean exit = false;
		int option;
		Scanner scanner = new Scanner(System.in);

		while (!exit) {
			if (!exit) {
				showMenu();
			}
			System.out.println("Nhap lua chon cua ban: ");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				function.inputNgoaiThanh();
				break;
			case 2:
				function.outputNgoaiThanh();
				break;
			case 3:
				function.inputNoiThanh();
				break;
			case 4:
				function.outputNoiThanh();
			case 0:
				return;

			default:
				break;
			}
		}
		scanner.close();
	}

}
