package entities;

public class Car {
	private String maSoChuyen; //
	private String tenTaiXe; // Nguoi lai xe
	private int soXe;
	private double doanhThu;

	public Car() {

	}

	public Car(String maSoChuyen, String tenTaiXe, int soXe, double doanhThu) {
		super();
		this.maSoChuyen = maSoChuyen;
		this.tenTaiXe = tenTaiXe;
		this.soXe = soXe;
		this.doanhThu = doanhThu;
	}

	public String getMaSoChuyen() {
		return maSoChuyen;
	}

	public void setMaSoChuyen(String maSoChuyen) {
		this.maSoChuyen = maSoChuyen;
	}

	public String getTenTaiXe() {
		return tenTaiXe;
	}

	public void setTenTaiXe(String tenTaiXe) {
		this.tenTaiXe = tenTaiXe;
	}

	public int getSoXe() {
		return soXe;
	}

	public void setSoXe(int soXe) {
		this.soXe = soXe;
	}

	public double getDoanhThu() {
		return doanhThu;
	}

	public void setDoanhThu(double doanhThu) {
		this.doanhThu = doanhThu;
	}

//	@Override
//	public String toString() {
//		return "Car [maSoChuyen=" + maSoChuyen + ", tenTaiXe=" + tenTaiXe + ", soXe=" + soXe + ", doanhThu=" + doanhThu
//				+ "]";
//	}
	public void display() {
		System.out.print("maSoChuyen=" + maSoChuyen + ", tenTaiXe=" + tenTaiXe + ", soXe=" + soXe + ", doanhThu=" + doanhThu);
	}
}
