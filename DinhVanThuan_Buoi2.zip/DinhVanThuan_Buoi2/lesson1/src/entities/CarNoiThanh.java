package entities;

public class CarNoiThanh extends Car {
	private int soTuyen;
	private double soKmDiDuoc;

	public CarNoiThanh() {
	}

	public CarNoiThanh(String maSoChuyen, String tenTaiXe, int soXe, double doanhThu, int soTuyen, double soKmDiDuoc) {
		super(maSoChuyen, tenTaiXe, soXe, doanhThu);
		this.soTuyen = soTuyen;
		this.soKmDiDuoc = soKmDiDuoc;
	}

	public int getSoTuyen() {
		return soTuyen;
	}

	public void setSoTuyen(int soTuyen) {
		this.soTuyen = soTuyen;
	}

	public double getSoKmDiDuoc() {
		return soKmDiDuoc;
	}

	public void setSoKmDiDuoc(double soKmDiDuoc) {
		this.soKmDiDuoc = soKmDiDuoc;
	}

	// @Override
	// public String toString() {
	// super.toString();
	// return "CarNoiThanh [soTuyen=" + soTuyen + ", soKmDiDuoc=" + soKmDiDuoc +
	// "]";
	// }
	public void show() {
		System.out.println("So tuyen: " + soTuyen + "So km di duoc: " + soKmDiDuoc);
	}

}
