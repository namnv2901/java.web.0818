package entities;

public class CarNgoaiThanh extends Car {
	private String noiDen;
	private double soNgayDiDuoc;

	public CarNgoaiThanh() {
	}

	public CarNgoaiThanh(String maSoChuyen, String tenTaiXe, int soXe, double doanhThu, String noiDen,
			double soNgayDiDuoc) {
		super(maSoChuyen, tenTaiXe, soXe, doanhThu);
		this.noiDen = noiDen;
		this.soNgayDiDuoc = soNgayDiDuoc;
	}

	public String getNoiDen() {
		return noiDen;
	}

	public void setNoiDen(String noiDen) {
		this.noiDen = noiDen;
	}

	public double getSoNgayDiDuoc() {
		return soNgayDiDuoc;
	}

	public void setSoNgayDiDuoc(double soNgayDiDuoc) {
		this.soNgayDiDuoc = soNgayDiDuoc;
	}
	
	public void show() {
//		super.display();
		System.out.println(" Noi den"+noiDen+"So ngay di duoc: "+soNgayDiDuoc);
		
	}
}
