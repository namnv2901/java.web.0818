package app;

import controller.Logic;

public class Main {

	public static void main(String[] args) {
		Logic logic = new Logic();
		logic.inputEmployee();
		logic.outputEmployee();
	}
}
