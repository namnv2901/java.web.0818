package controller;

import java.util.Scanner;

import entities.Employee;

public class Logic {
	Employee emp = new Employee();

	public void inputEmployee() {
		Scanner scanner = new Scanner(System.in);
		System.out.print("ID: ");
		emp.setId(scanner.nextInt());
		scanner.nextLine();
		System.out.print("NAME: ");
		emp.setName(scanner.nextLine());
		emp.setNgayThangNam();
		System.out.print("Luong: ");
		emp.setLuong(scanner.nextDouble());
		emp = new Employee(emp.getId(), emp.getName(), emp.getNgayThangNam(), emp.getLuong());
		scanner.close();
	}

	public void outputEmployee() {
		System.out.println(emp.toString());
	}
}
