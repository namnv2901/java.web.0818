package entities;

public class Person {
	private int id;
	private String name;
	private DayMonthYear ngayThangNam = null;

	public Person() {
	}

	public Person(int id, String name, DayMonthYear ngayThangNam) {
		super();
		this.id = id;
		this.name = name;
		this.ngayThangNam = ngayThangNam;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DayMonthYear getNgayThangNam() {
		return ngayThangNam;
	}

	public void setNgayThangNam() {
		// this.ngayThangNam.inputDate();
		DayMonthYear date = new DayMonthYear();
		date.inputDate();
		this.ngayThangNam = new DayMonthYear(date.getDay(), date.getMonth(), date.getYear());
	}

	@Override
	public String toString() {
		return "[id=" + id + ", name=" + name + ", Date=" + ngayThangNam.toString() + "]";
	}

}
