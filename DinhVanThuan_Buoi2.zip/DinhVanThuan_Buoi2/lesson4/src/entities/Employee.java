package entities;

public class Employee extends Person {
	private double luong;

	public Employee() {
	}

	public Employee(int id, String name, DayMonthYear ngayThangNam, double luong) {
		super(id, name, ngayThangNam);
		this.luong = luong;
	}

	public double getLuong() {
		return luong;
	}

	public void setLuong(double luong) {
		this.luong = luong;
	}

	@Override
	public String toString() {
		return "Employee" + super.toString() +", "+ "[luong= " + getLuong() + "] ";
	}

}
